# NEP Movies Android 1.1.0

Native Kotlin + Jetpack Compose Android app for NEP Movies.

## Current build

- Native Android, not a WebView
- Android 7.0+ (API 24)
- Jetpack Compose + Material 3
- Dark cinematic interface with red/gold accents
- Home, Movies, TV Shows and My List tabs
- WordPress REST API discovery for movies, TV shows and episodes
- Image loading with Coil
- Search field ready for server-side WordPress search
- Cloud build configuration for Codemagic
- GitHub Actions debug APK workflow

## Backend

The default backend is:

https://nepmovies.rf.gd/

The app attempts the public WordPress REST API routes:

- `/wp-json/wp/v2/movies`
- `/wp-json/wp/v2/tvshows`
- `/wp-json/wp/v2/tv`
- `/wp-json/wp/v2/episodes`

DooPlay may not expose its custom post types through the standard REST API. If those routes are unavailable, the next backend step is to add a small read-only REST endpoint to the NEP Movies WordPress child theme/plugin that returns the DooPlay movie/TV/season/episode data and authorized player sources.

## Playback

The app deliberately does not hard-code third-party or unauthorized streaming URLs. The final player should consume a source returned by the NEP Movies backend.

## Cloud build

### Codemagic

The repository includes `codemagic.yaml`. Add the repository to Codemagic and run the `NEP Movies Android` workflow. The resulting debug APK is:

`app/build/outputs/apk/debug/app-debug.apk`

Codemagic's native Android documentation confirms that a `codemagic.yaml` can build an APK with Gradle and expose it as a build artifact.

### GitHub Actions

The repository also contains `.github/workflows/android.yml`. Open the Actions tab and manually run **Android Debug APK**. The APK is uploaded as a workflow artifact.
