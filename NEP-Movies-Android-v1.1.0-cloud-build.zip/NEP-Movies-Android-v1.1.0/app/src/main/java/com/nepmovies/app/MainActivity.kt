package com.nepmovies.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

private val Black = Color(0xFF09090B)
private val Surface = Color(0xFF141416)
private val Surface2 = Color(0xFF1C1C20)
private val Red = Color(0xFFE50914)
private val Gold = Color(0xFFFFC107)
private val Muted = Color(0xFFA1A1AA)

data class MediaItem(
    val id: Int,
    val title: String,
    val image: String = "",
    val overview: String = "",
    val rating: String = "",
    val year: String = "",
    val type: String = "Movie",
    val link: String = ""
)

class MediaRepository {
    private val client = OkHttpClient()

    suspend fun getItems(type: String, page: Int = 1, search: String = ""): List<MediaItem> =
        withContext(Dispatchers.IO) {
            val candidates = when (type) {
                "Movie" -> listOf("wp-json/wp/v2/movies")
                "TV" -> listOf("wp-json/wp/v2/tvshows", "wp-json/wp/v2/tv")
                "Episode" -> listOf("wp-json/wp/v2/episodes")
                "Season" -> listOf("wp-json/wp/v2/seasons")
                else -> listOf("wp-json/wp/v2/movies")
            }

            for (endpoint in candidates) {
                val url = BuildConfig.API_BASE_URL.trimEnd('/') + "/" + endpoint +
                    "?per_page=20&page=$page" +
                    if (search.isNotBlank()) "&search=${URLEncoder.encode(search, "UTF-8")}" else ""
                try {
                    val req = Request.Builder().url(url).get().build()
                    client.newCall(req).execute().use { response ->
                        if (!response.isSuccessful) return@use
                        val body = response.body?.string() ?: return@use
                        val arr = JSONArray(body)
                        val result = mutableListOf<MediaItem>()
                        for (i in 0 until arr.length()) {
                            val o = arr.optJSONObject(i) ?: continue
                            val title = htmlToText(o.optJSONObject("title")?.optString("rendered").orEmpty())
                            val excerpt = htmlToText(o.optJSONObject("excerpt")?.optString("rendered").orEmpty())
                            val content = htmlToText(o.optJSONObject("content")?.optString("rendered").orEmpty())
                            val embedded = o.optJSONObject("_embedded")
                            val media = embedded?.optJSONArray("wp:featuredmedia")
                            val image = media?.optJSONObject(0)?.optString("source_url").orEmpty()
                            val meta = o.optJSONObject("meta")
                            result += MediaItem(
                                id = o.optInt("id"),
                                title = title.ifBlank { "Untitled" },
                                image = image,
                                overview = excerpt.ifBlank { content },
                                rating = meta?.optString("rating").orEmpty(),
                                year = o.optString("date").take(4),
                                type = type,
                                link = o.optString("link")
                            )
                        }
                        if (result.isNotEmpty()) return@withContext result
                    }
                } catch (_: Exception) {
                    // Try the next endpoint candidate.
                }
            }
            emptyList()
        }

    private fun htmlToText(value: String): String =
        value.replace(Regex("<[^>]*>"), " ")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .trim()
}

class MainViewModel : ViewModel() {
    private val repo = MediaRepository()

    var movies by mutableStateOf<List<MediaItem>>(emptyList())
        private set
    var shows by mutableStateOf<List<MediaItem>>(emptyList())
        private set
    var episodes by mutableStateOf<List<MediaItem>>(emptyList())
        private set
    var loading by mutableStateOf(true)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            loading = true
            error = null
            try {
                val m = repo.getItems("Movie")
                val s = repo.getItems("TV")
                val e = repo.getItems("Episode")
                movies = m
                shows = s
                episodes = e
                if (m.isEmpty() && s.isEmpty() && e.isEmpty()) {
                    error = "No catalog data was returned. The WordPress API may need the DooPlay content types exposed."
                }
            } catch (t: Throwable) {
                error = t.message ?: "Unable to connect to NEP Movies."
            } finally {
                loading = false
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NEPMoviesApp() }
    }
}

@Composable
fun NEPMoviesApp(vm: MainViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<MediaItem?>(null) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red,
            secondary = Gold,
            background = Black,
            surface = Surface,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        if (selected != null) {
            DetailScreen(selected!!, onBack = { selected = null })
        } else {
            Scaffold(
                containerColor = Black,
                bottomBar = {
                    NavigationBar(containerColor = Surface) {
                        listOf(
                            "Home" to Icons.Default.Home,
                            "Movies" to Icons.Default.Movie,
                            "TV Shows" to Icons.Default.Tv,
                            "My List" to Icons.Default.Favorite
                        ).forEachIndexed { index, pair ->
                            NavigationBarItem(
                                selected = tab == index,
                                onClick = { tab = index },
                                icon = { Icon(pair.second, null) },
                                label = { Text(pair.first) }
                            )
                        }
                    }
                }
            ) { padding ->
                when (tab) {
                    0 -> HomeScreen(vm, search, { search = it }, { selected = it }, padding)
                    1 -> CatalogScreen("Movies", vm.movies, { selected = it }, padding)
                    2 -> CatalogScreen("TV Shows", vm.shows, { selected = it }, padding)
                    else -> EmptyListScreen(padding)
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    vm: MainViewModel,
    search: String,
    onSearch: (String) -> Unit,
    onSelect: (MediaItem) -> Unit,
    padding: PaddingValues
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Box(
                Modifier.fillMaxWidth().height(240.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF321016), Black)
                        )
                    )
            ) {
                Column(
                    Modifier.align(Alignment.BottomStart).padding(20.dp)
                ) {
                    Text("NEP MOVIES", color = Red, fontWeight = FontWeight.Black)
                    Text(
                        "Movies & TV, made simple.",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Browse the latest titles from your NEP Movies library.",
                        color = Muted
                    )
                }
            }
        }

        item {
            OutlinedTextField(
                value = search,
                onValueChange = onSearch,
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                singleLine = true,
                placeholder = { Text("Search movies & TV shows") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Red,
                    unfocusedBorderColor = Surface2
                )
            )
        }

        if (vm.loading) {
            item { Box(Modifier.fillMaxWidth().padding(40.dp), Alignment.Center) { CircularProgressIndicator() } }
        }

        vm.error?.let { message ->
            item {
                Card(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = Surface2)
                ) {
                    Text(message, Modifier.padding(16.dp), color = Muted)
                }
            }
        }

        item { SectionTitle("Featured Movies") }
        item { HorizontalCards(vm.movies.take(10), onSelect) }

        item { SectionTitle("TV Shows") }
        item { HorizontalCards(vm.shows.take(10), onSelect) }

        item { SectionTitle("Latest Episodes") }
        item { HorizontalCards(vm.episodes.take(10), onSelect) }

        item {
            TextButton(
                onClick = vm::refresh,
                modifier = Modifier.padding(16.dp)
            ) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("Refresh catalog") }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 10.dp),
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold
    )
}

@Composable
fun HorizontalCards(items: List<MediaItem>, onSelect: (MediaItem) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items.forEach { item ->
            MediaCard(item, onSelect)
        }
    }
}

@Composable
fun MediaCard(item: MediaItem, onSelect: (MediaItem) -> Unit) {
    Card(
        modifier = Modifier.width(145.dp).clickable { onSelect(item) },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Surface)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(205.dp)) {
                if (item.image.isNotBlank()) {
                    AsyncImage(
                        model = item.image,
                        contentDescription = item.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(Modifier.fillMaxSize().background(Surface2), Alignment.Center) {
                        Icon(Icons.Default.Movie, null, tint = Muted, modifier = Modifier.size(40.dp))
                    }
                }
                if (item.rating.isNotBlank()) {
                    Surface(
                        Modifier.align(Alignment.TopEnd).padding(7.dp),
                        shape = RoundedCornerShape(8.dp),
                        color = Color.Black.copy(alpha = .75f)
                    ) {
                        Row(Modifier.padding(horizontal = 7.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, null, tint = Gold, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(3.dp))
                            Text(item.rating, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
            Text(
                item.title,
                Modifier.padding(10.dp),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun CatalogScreen(
    title: String,
    items: List<MediaItem>,
    onSelect: (MediaItem) -> Unit,
    padding: PaddingValues
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        items(items) { item ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .background(Surface).clickable { onSelect(item) }
                    .padding(10.dp)
            ) {
                if (item.image.isNotBlank()) {
                    AsyncImage(
                        model = item.image,
                        contentDescription = item.title,
                        modifier = Modifier.size(width = 82.dp, height = 116.dp).clip(RoundedCornerShape(10.dp)),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(Modifier.size(82.dp, 116.dp).background(Surface2), Alignment.Center) {
                        Icon(Icons.Default.Movie, null, tint = Muted)
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, fontWeight = FontWeight.Bold)
                    if (item.year.isNotBlank()) Text(item.year, color = Muted)
                    if (item.rating.isNotBlank()) Text("★ ${item.rating}", color = Gold)
                    Text(item.overview, color = Muted, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        if (items.isEmpty()) {
            item { Text("No items available yet.", color = Muted) }
        }
    }
}

@Composable
fun DetailScreen(item: MediaItem, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Black)) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
        }
        LazyColumn {
            item {
                if (item.image.isNotBlank()) {
                    AsyncImage(
                        model = item.image,
                        contentDescription = item.title,
                        modifier = Modifier.fillMaxWidth().height(390.dp),
                        contentScale = ContentScale.Crop
                    )
                }
            }
            item {
                Column(Modifier.padding(18.dp)) {
                    Text(item.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        if (item.year.isNotBlank()) Text(item.year, color = Muted)
                        if (item.rating.isNotBlank()) Text("★ ${item.rating}", color = Gold)
                        Text(item.type, color = Red)
                    }
                    Spacer(Modifier.height(18.dp))
                    Text(item.overview.ifBlank { "No synopsis available." }, color = Muted)
                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = { /* Native player integration will use an authorized backend source. */ },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Red)
                    ) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (item.type == "Episode") "Watch Episode" else "Play")
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.FavoriteBorder, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Add to My List")
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyListScreen(padding: PaddingValues) {
    Box(Modifier.fillMaxSize().padding(padding), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.FavoriteBorder, null, modifier = Modifier.size(56.dp), tint = Muted)
            Spacer(Modifier.height(12.dp))
            Text("Your list is empty", fontWeight = FontWeight.Bold)
            Text("Add movies and shows here later.", color = Muted)
        }
    }
}
